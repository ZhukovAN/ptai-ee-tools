DISCLAIMER: OWASP does not endorse any commercial tools, including this one. Benchmark support for this tool is simply for user convenience and should not be considered an endorsement of this tool.

Checkmarx CxIAST is a commercial tool. If you are interested in running Checkmarx CxIAST on the Benchmark, you'll have to get a license for it from the vendor just like you would for any commercial tool. Once you have it, you need to unzip the cxiast-java-agent.zip file in this directory in order to run the Benchmark with Checkmarx CxIAST using one of the runBenchmark_wCxIAST scripts, and then crawl the Benchmark to generate scan results with one of the runCrawler scripts.

See the Tool Scanning Tips page at OWASP (https://owasp.org/www-project-benchmark/#div-scanning_tips) for the latest instructions on how to scan the Benchmark with any vulnerability detection tool, including Checkmarx CxIAST.
