<?php
    unlink($_GET['file']);
?>