<?php
    echo $_GET['a'];
?>