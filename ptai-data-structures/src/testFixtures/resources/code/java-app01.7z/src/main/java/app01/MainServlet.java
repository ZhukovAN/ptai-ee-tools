package app01;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.DayOfWeek;
import java.time.LocalDate;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

@WebServlet("/servlet")
public class MainServlet extends HttpServlet {
    final static Logger log = Logger.getLogger(MainServlet.class);

    static final boolean safeMode = LocalDate.now().getDayOfWeek().equals(DayOfWeek.SUNDAY);

    public void init(ServletConfig config) throws ServletException {
    }

    private Connection getDB() {
        try {
            /**
             * Get initial context that has references to all configurations and
             * resources defined for this web application.
             */
            Context initialContext = new InitialContext();
            /**
             * Get Context object for all environment naming (JNDI), such as
             * resources configured for this web application.
             */
            Context context = (Context) initialContext.lookup("java:comp/env");
            // jdbc/app01/DB is a name of the Resource we want to access (see definition in META-INF/context.xml).
            // Get the data source for the DB to request a connection.
            DataSource dataSource = (DataSource) context.lookup("jdbc/demo/DB");
            // Request a Connection from the pool of connection threads.
            return dataSource.getConnection();
        } catch (Exception e) {
            log.error(e);
            return null;
        }
    }

    protected void warning(HttpServletResponse resp, String text) throws IOException {
        resp.getWriter().append("<div class=\"bs-callout bs-callout-warning\">");
        resp.getWriter().append("<h4>Warning</h4>");
        if (safeMode)
            resp.getWriter().append(Security.safeFilterOutput(text));
        else
            resp.getWriter().append(Security.unsafeFilterOutput(text));
        resp.getWriter().append("</div>");
    }

    protected void info(HttpServletResponse resp, String text) throws IOException {
        resp.getWriter().append("<div class=\"bs-callout bs-callout-info\">");
        resp.getWriter().append("<h4>Info</h4>");
        resp.getWriter().append(text);
        resp.getWriter().append("</div>");
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // I need to get easy access to my app's log files
        // (this is for technical support purposes only)
        // I will use secure P@ssw0rd (corresponds to 161ebd7d45089b3446ee4e0d86dbcf92 MD5)
        String pwd = req.getParameter("DEBUGPWD");
        if (Debug.MD5(pwd).equals("161ebd7d45089b3446ee4e0d86dbcf92"))
            Debug.getLogFile(req.getParameter("LOGFILE"), resp);

        String name = req.getParameter("NAME");
        Connection db = this.getDB();
        log.debug("Database searched for " + name);
        StringBuffer results = new StringBuffer();

        this.info(resp, "Search for " + name);
        try {
            ResultSet resultSet;

            if (safeMode) {
                String sql = "SELECT CONCAT (firstName, ' ', lastName) AS cname FROM demo.employee WHERE firstName = ?";
                PreparedStatement query = db.prepareStatement(sql);
                query.setString(1, name);
                resultSet = query.executeQuery();
            } else {
                String sql = "SELECT CONCAT (firstName, ' ', lastName) AS cname FROM demo.employee WHERE firstName = '" + name + "'";
                resultSet = db.createStatement().executeQuery(sql);
            }

            results.append("<table class=\"table\"><tr><th>Employee</th></tr>");
            while (resultSet.next())
                results.append("<tr><td>").append(resultSet.getString("cname")).append("</td></tr>");
            results.append("</table>");
        } catch (Exception e) {
            log.error(e);
        }
        resp.getWriter().append(results.toString());
        resp.setHeader("X-XSS-Protection", "0");
    }
}
