<?php
    $password = 'P@ssw0rd';
    
    $a = $_GET['a'];
    $b = $_GET['b'];

    function XSS($text) {
        echo $text;
    }
    
    function AFD($file) {
        unlink($file);
    }
	
    XSS($a . $b);
   
    AFD($_GET['file']);
?>