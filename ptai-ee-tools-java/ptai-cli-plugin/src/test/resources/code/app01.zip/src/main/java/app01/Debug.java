package app01;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

public class Debug {
    public static String MD5(String data) {
        if (null == data) return "";
        final StringBuilder builder = new StringBuilder();

        MessageDigest md5;
        try {
            md5 = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md5.digest(data.getBytes());
            for (byte hashByte : hashBytes)
                builder.append(String.format("%02x", hashByte));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return builder.toString();
    }

    public static void getLogFile(String file, HttpServletResponse resp)
            throws ServletException, IOException {
        // According to log4j.appender.FILE.File setting from log4j.properties
        // Only the log files are needed,
        String logs = System.getProperty("catalina.base") + "/logs/";
        File logFile = new File(logs + file);
        // Read the log file
        resp.setContentType("application/octet-stream");
        // String l_strName = logFile.getName().replaceAll("\\W", "");

        resp.setHeader("Content-Disposition", "filename=\"" + logFile.getName().replaceAll("\\W", "") + "\"");
        FileInputStream fis = new FileInputStream(logFile);
        OutputStream out = resp.getOutputStream();

        byte[] buffer = new byte[4096];
        int bytesRead = -1;

        while ((bytesRead = fis.read(buffer)) != -1)
            out.write(buffer, 0, bytesRead);

        fis.close();
        out.close();
    }
}
