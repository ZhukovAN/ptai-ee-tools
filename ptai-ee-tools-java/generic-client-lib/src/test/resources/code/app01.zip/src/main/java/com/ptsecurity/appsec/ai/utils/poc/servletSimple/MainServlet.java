package com.ptsecurity.appsec.ai.utils.poc.servletSimple;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.stream.Collectors;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.sql.DataSource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ptsecurity.appsec.ai.utils.poc.servletSimple.domain.EmployeesSearchResult;
import org.apache.log4j.Logger;

@WebServlet("/servlet")
@MultipartConfig
public class MainServlet extends HttpServlet {
    static final Logger log = Logger.getLogger(MainServlet.class);
	static final boolean safeMode = LocalDate.now().getDayOfWeek().equals(DayOfWeek.SUNDAY);
    static final String secureDebugPwd = "161ebd7d45089b3446ee4e0d86dbcf92";

    public void init(ServletConfig config) throws ServletException {}

    private Connection getDB() {
        Connection l_objRes = null;
        try {
            /**
             * Get initial context that has references to all configurations and
             * resources defined for this web application.
             */
            Context ctx = new InitialContext();
            /**
             * Get Context object for all environment naming (JNDI), such as
             * resources configured for this web application.
             */
            Context envCtx = (Context) ctx.lookup("java:comp/env");
            // jdbc/app01/DB is a name of the Resource we want to access (see definition in META-INF/context.xml).
            // Get the data source for the DB to request a connection.
            DataSource dataSource = (DataSource)envCtx.lookup("jdbc/servletSimple/DB");
            // Request a Connection from the pool of connection threads.
            return dataSource.getConnection();
        } catch (Exception e) {
            log.error(e);
            return null;
        }
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("X-XSS-Protection", "0");
        Part filePart = request.getPart("file");

        InputStream fis = filePart.getInputStream();
        InputStreamReader reader = new InputStreamReader(fis, "UTF-8");
        try (BufferedReader br = new BufferedReader(reader)) {
            String xml = br.lines().collect(Collectors.joining(System.lineSeparator()));
            EmployeesSearchResult.Employee emp = EmployeesSearchResult.Employee.fromString(xml);
            String sql = "INSERT INTO pt.employee (`lastName`, `firstName`) VALUES (?, ?)";
            PreparedStatement insert = this.getDB().prepareStatement(sql);
            insert.setString(1, emp.getLastName());
            insert.setString(2, emp.getFirstName());
            insert.execute();

            PrintWriter out = response.getWriter();
            out.print(new ObjectMapper().writeValueAsString(emp));
            out.flush();
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            log.error(e);
            throw new ServletException(e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.setHeader("X-XSS-Protection", "0");

        String firstName = request.getParameter("firstName");
        Connection db = this.getDB();
        log.debug("Database searched for " + firstName);
        StringBuffer res = new StringBuffer();

        try {
            ResultSet rs;
            
        	if (safeMode) {
        		String sql = "SELECT lastName, firstName FROM pt.employee WHERE firstName = ?";
        		PreparedStatement query = db.prepareStatement(sql);
        		query.setString(1, firstName);
        		rs = query.executeQuery();
        	} else {
        		String sql = "SELECT lastName, firstName FROM pt.employee WHERE firstName = '" + firstName + "'";
        		rs = db.createStatement().executeQuery(sql);
        	}

            EmployeesSearchResult employees = new EmployeesSearchResult();
        	employees.setFirstName(firstName);
            while (rs.next()) {
                EmployeesSearchResult.Employee employee = new EmployeesSearchResult.Employee(rs.getString("lastName"), rs.getString("firstName"));
                employees.getEmployees().add(employee);
            }
            PrintWriter out = response.getWriter();
            out.print(new ObjectMapper().writeValueAsString(employees));
            out.flush();
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            log.error(e);
        }
    }
}
