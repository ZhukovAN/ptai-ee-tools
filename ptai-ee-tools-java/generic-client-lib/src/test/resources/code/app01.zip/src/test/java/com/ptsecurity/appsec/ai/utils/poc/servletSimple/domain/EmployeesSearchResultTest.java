package com.ptsecurity.appsec.ai.utils.poc.servletSimple.domain;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.junit.jupiter.api.Test;

import java.beans.XMLEncoder;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

class EmployeesSearchResultTest {

    @Test
    void testXmlSerialization() throws IOException {
        EmployeesSearchResult.Employee emp = new EmployeesSearchResult.Employee("Smith", "John");
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        XMLEncoder enc = new XMLEncoder(os);
        enc.writeObject(emp);
        enc.close();
        System.out.println(os.toString());

        XmlMapper xmlMapper = new XmlMapper();
        System.out.println(xmlMapper.writeValueAsString(emp));

        os = new ByteArrayOutputStream();
        ObjectOutputStream out = new ObjectOutputStream(os);
        emp.setFirstName("Vanessa");
        emp.setLastName("Anderson");
        out.writeObject(emp);
        out.close();
        System.out.println(Base64.getEncoder().encodeToString(os.toByteArray()));
    }
}