package com.ptsecurity.appsec.ai.utils.poc.servletSimple.domain;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.beans.XMLDecoder;
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@NoArgsConstructor
public class EmployeesSearchResult {
    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @DatabaseTable(tableName = "employee")
    public static class Employee implements Serializable {
        private static final long serialVersionUID = -6699180358681226149L;
        @DatabaseField(generatedId = true)
        private long id = -1;

        @DatabaseField(canBeNull = false)
        private String lastName;

        @DatabaseField(canBeNull = false)
        private String firstName;

        public Employee(String lastName, String firstName) {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public static Employee fromXmlV1(String xml) throws Exception {
            ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes());
            XMLDecoder decoder = new XMLDecoder(is);
            Object obj = decoder.readObject();
            if (obj instanceof EmployeesSearchResult.Employee) return (Employee) obj;
            throw new Exception("XML v1 parse failed");
        }

        public static Employee fromXmlV2(String xml) throws Exception {
            return new XmlMapper().readValue(xml, EmployeesSearchResult.Employee.class);
        }

        public static Employee fromBase64(String base64) throws Exception {
            ByteArrayInputStream is = new ByteArrayInputStream(Base64.getDecoder().decode(base64.replaceAll("(\r\n|\n)", "")));
            ObjectInputStream ois = new ObjectInputStream(is);
            return (Employee) ois.readObject();
        }

        public static Employee fromString(String data) throws Exception {
            try {
                return Employee.fromXmlV1(data);
            } catch (Exception e1) {
                try {
                    return Employee.fromXmlV2(data);
                } catch (Exception e2) {
                    return Employee.fromBase64(data);
                }
            }
        }
    }

    @Getter
    List<Employee> employees = new ArrayList<>();
    @Getter @Setter
    protected String firstName = "";
}
