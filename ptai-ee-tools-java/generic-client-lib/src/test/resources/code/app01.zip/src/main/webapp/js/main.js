$(function () {
    $("#search").click(function () {
        search($("#ctx").text() + "/servlet")
    });

    $("#uploadFile").click(function () {
        $("#file").trigger("click");
    });

    $('input[type="file"]').change(function() {
        upload($("#ctx").text() + "/servlet");
    });
});

tableId = "#searchResults";
tableBodyId = tableId + " > tbody";

function upload(url) {
    pre();

    var data = new FormData();
    data.append("file", $("#file")[0].files[0]);
    $("#file").val("");

    $.ajax(url, {
        type: "PUT",
        data: data,
        cache: false,
        contentType: false,
        processData: false,
        statusCode: {
            200: function (response) {
                info("Employee " + response.firstName + " " + response.lastName + " was added to database");
            }
        }, success: function () {
            post();
        }, error: function (xhr, status, message) {
            error("Something bad happened on a server");
            post();
        }
    });
}

function search(url) {
    pre();
    $.ajax(url, {
        // type: OutageViewModel.Id() == 0 ? "POST" : "PUT",
        type: "GET",
        data: { firstName: $('#firstName').val() },
        statusCode: {
            200: function (response) {
                if( !$.isArray(response.employees) || !response.employees.length )
                    warning("Employee with first name " + response.firstName + " not found");
                else {
                    info("Search results for employee with first name " + response.firstName);
                    $(tableBodyId).empty();
                    $.each(response.employees, function (i, item) {
                        $(tableBodyId).append("<tr>");
                        $(tableBodyId).append("<td>" + item.lastName + "</td>");
                        $(tableBodyId).append("<td>" + item.firstName + "</td>");
                        $(tableBodyId).append("</tr>");
                    });
                    $(tableId).prop('style', 'display:table');
                }
            }
        }, success: function () {
            post();
        }, error: function (xhr, status, message) {
            error("Something bad happened on a server");
            post();
        }
    });
}

function pre() {
    $(".btn").prop('disabled', true);
    $("#message").prop('style', 'display:none');
    $(tableId).prop('style', 'display:none');
}

function post() {
    $(".btn").prop('disabled', false);
}

function error(message) {
    $("#message-caption").html("Error");
    $("#message-text").html($('<div />').text(message).html());
    $("#message").removeClass();
    $("#message").addClass("bs-callout bs-callout-danger")
    $("#message").prop('style', 'display:inherit');
}

function warning(message) {
    $("#message-caption").html("Warning");
    $("#message-text").html($('<div />').text(message).html());
    $("#message").removeClass();
    $("#message").addClass("bs-callout bs-callout-warning");
    $("#message").prop('style', 'display:inherit');
}

function info(message) {
    $("#message-caption").html("Info");
    $("#message-text").html($('<div />').text(message).html());
    $("#message").removeClass();
    $("#message").addClass("bs-callout bs-callout-info");
    $("#message").prop('style', 'display:inherit');
}

