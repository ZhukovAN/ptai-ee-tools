package com.ptsecurity.appsec.ai.utils.poc.servletSimple;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@WebServlet("/debug")
public class DebugServlet extends HttpServlet {
    static final boolean legacyMode = true;
    static final String secureDebugPwd = "161ebd7d45089b3446ee4e0d86dbcf92".toUpperCase();

    public static String MD5(String debugPwd) {
        if (null == debugPwd) return null;

        if (legacyMode) {
            final StringBuilder builder = new StringBuilder();

            MessageDigest digest;
            try {
                digest = MessageDigest.getInstance("MD5");
                byte[] hash = digest.digest(debugPwd.getBytes());
                for (byte value : hash)
                    builder.append(String.format("%02x", value));
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
                return null;
            }
            return builder.toString().toUpperCase();
        } else {
            return DigestUtils.md5Hex(debugPwd).toUpperCase();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // I need to get easy access to my app's log files
        // (this is for technical support purposes only)
        // I will use secure P@ssw0rd (corresponds to 161ebd7d45089b3446ee4e0d86dbcf92 MD5)
        if (true) {
            String debugPwd = request.getParameter("debugPwd");

            String md5Hex = DebugServlet.MD5(debugPwd);
            if (null == md5Hex) return;

            if (!secureDebugPwd.equalsIgnoreCase(md5Hex)) return;
        }

        // Only the log files are needed,
        String logFileName = System.getProperty("catalina.base") + File.separator;
        logFileName += "logs" + File.separator + request.getParameter("logFile");

        if (legacyMode) {
            FileInputStream inputStream = new FileInputStream(logFileName);

            byte[] buffer = new byte[4096];
            int bytesRead;

            while (-1 != (bytesRead = inputStream.read(buffer)))
                response.getOutputStream().write(buffer, 0, bytesRead);

            inputStream.close();
        } else {
            File logFile = new File(logFileName);
            FileUtils.copyFile(logFile, response.getOutputStream());
        }
        // Read the log file
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "filename=\"" + FilenameUtils.getName(logFileName) + "\"");
    }
}
